#ifndef FUNCTION_H
#define FUNCTION_H
#include<iostream>
using namespace std;

/* Write Your Code Here */





/*----------------------*/ 

#endif








