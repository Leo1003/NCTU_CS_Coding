#include <iostream>
#include <string>
using namespace std;

class IntegerSet{
	public:
		IntegerSet(int);
		~IntegerSet(){};
		IntegerSet Union_of_Set(IntegerSet);
		IntegerSet Intersection_of_Set(IntegerSet);
		void InsertElement(int);
		void DeleteElement(int);
		bool isEqualTo(IntegerSet);
		void printSet();
	private:
		bool set[100];
		int size;
};

