#include<iostream>
using namespace std;

class User{
	public:
		User(){};
		User(string _id, char _gender);
		~User(){};
	private:
		string id;
		char gender;
};

class SavingsAccount{
	public:
		SavingsAccount(){};
		SavingsAccount(float AccountValue, const User&);
		~SavingsAccount(){};
		static float annualInterestRate;
		void calculateMonthlyInterest();
		static void modifyInterestRate(float InterestRate);
		void deposit(float cash);
		void withdraw(float cash);
		float GetBalance() const { return savingsBalance; }
	private:
		float savingsBalance;
		User user;
};