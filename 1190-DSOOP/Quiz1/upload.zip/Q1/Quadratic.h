#include<math.h>
#include<iostream>
using namespace std;

class Quadratic{
	public:
		Quadratic(double, double, double);
		void solver();
		void print();
	private:
		double a;
		double b;
		double c;
		double real, imag;
};
