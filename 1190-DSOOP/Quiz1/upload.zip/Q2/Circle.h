#include<stdio.h>
#include<math.h>
#define PI 3.1415926
#include<iomanip>
#include<iostream>
using namespace std;
class Circle{
    public:
        Circle();
        float cal_area();
        float cal_circumference();
        float set_circle(float , float , float );
        float set_circle(float , float , float , Circle);
		void print();
    private:
        float center_x;
        float center_y;
        float radius;
};
