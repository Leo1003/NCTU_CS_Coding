#ifndef ZooAnimal_H
#define ZooAnimal_H

#include <iostream>
#include <cstring>
#include <string.h>
using namespace std;

/*-----Write Your Code Here----*/






/*------------------------------*/

#endif
