#include <iostream>
#include <cmath>
#include <cstring> 
using namespace std;

/*----Write Your Answer Here-----*/






